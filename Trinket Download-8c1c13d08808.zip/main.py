from tkinter import Tk

window=Tk()

window.title('Demo Widow')
window.geometry('400x300')
window.mainloop()